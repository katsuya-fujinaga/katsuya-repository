---
title: HITORI-BIZ｜WordPressテーマ
project: ひとびじ
type: knowledge
status: draft
tags:
  - project
  - wordpress
  - website
制作日: 2026-07-25
---

# HITORI-BIZ｜WordPressテーマ

Version: **1.2.0**

## アップロード

1. `hitori-biz.zip` を用意（このフォルダ直下に `style.css` がある状態）
2. WordPress → **外観 → テーマ → 新規追加 → テーマのアップロード**
3. 有効化
4. **設定 → 表示設定** でホームページを固定ページにする（任意）

## パス

```
katsuya_project/ひとびじ/サイト/hitori-biz/
katsuya_project/ひとびじ/サイト/hitori-biz.zip
```

## 1.1.0 の主な更新

- ファーストビューに価値提案＋CTA
- 悩み／WORKS／PROFILE／選ばれる理由／流れ／FAQ を追加
- SERVICEを2列レイアウトに短縮
- メタディスクリプション・OGP・Xカード・canonical をテーマ側で出力
- 記事ページのタイトルを個別化
